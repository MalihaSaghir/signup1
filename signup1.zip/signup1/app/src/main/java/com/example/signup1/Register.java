package com.example.signup1;

import android.content.Intent;
import android.provider.Contacts;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {

    TextView btn;
    private EditText musername, memail, mpassword, mphone_no;

    Button RegisterBtn;

    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        btn = findViewById(R.id.alreadyaccount);

        musername = findViewById(R.id.musername);
        memail = findViewById(R.id.memail);
        mpassword = findViewById(R.id.mpassword);
        mphone_no = findViewById(R.id.mphone_no);
        RegisterBtn = findViewById(R.id.mregister);


        btn.setOnClickListener((view) -> {
            startActivity(new Intent(Register.this, login.class));

        });

        RegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("users");

                String username = musername.getText().toString();
                String email = memail.getText().toString();
                String password = mpassword.getText().toString();
                String number = mphone_no.getText().toString();

                HelperClass helperClass = new HelperClass(username, email, password, number);
                reference.child(username).setValue(helperClass);

                Toast.makeText(Register.this, "You have signup successfully!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent( Register.this, login.class);
                startActivity(intent);
                // make function for validation and pass all parameters

                boolean check =  validateinfo(username, email, password, number);
                if(check==true)
                {
                    Toast.makeText(getApplicationContext(), "Data is Valid", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Sorry check information again", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent( Register.this, login.class);
                startActivity(intent);

            }
        });


    }

    private boolean validateinfo(String username, String email, String password, String
            number)
    {

        if (username.length() == 0)
        {
            musername.requestFocus();
            musername.setError("Field can't be empty");
            return false;
        }
        else if(!username.matches(  "[a-zA-Z]+"))
        {
            musername.requestFocus();
            musername.setError("Alphabetical characters will be only valid");
            return false;
        }
        else if(email.length() ==0)
        {
            memail.requestFocus();
            memail.setError("Field can't be empty");
            return false;
        }
        else if(!email.matches(  "[a-zA-Z0-9._-]+@+[a-z]+\\.+[a-z]+"))
        {
            memail.requestFocus();
            memail.setError("Enter valid email");
            return false;
        }

        else if(number.length() ==0)
        {
            mphone_no.requestFocus();
            mphone_no.setError("Field can't be empty");
            return false;
        }

        else if(!number.matches(  "^[+][0-9]{10,13}$"))
        {
            mphone_no.requestFocus();
            mphone_no.setError("Correct Format: +92xxxxxxxxxx");
            return false;
        }
        else if(password.length() <=8)
        {
            mpassword.requestFocus();
            mpassword.setError("password must be 8 characters");
            return false;
        }
        else {
            return true;
        }

    }
}