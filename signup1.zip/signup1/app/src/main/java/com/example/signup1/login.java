package com.example.signup1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class login extends AppCompatActivity {
    TextView btn;
    private EditText memail, mpassword;
    Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btn = findViewById(R.id.newAccount);
        memail = findViewById(R.id.memail);
        mpassword = findViewById(R.id.mpassword);
        btnLogin = findViewById(R.id.loginBtn);


        btn.setOnClickListener((view) -> {
            startActivity(new Intent(login.this, Register.class));
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = memail.getText().toString();
                String password = mpassword.getText().toString();
                boolean isValid = validateinfo(email, password);

                if (isValid) {
                    checkUser(email, password);
                }
            }
        });
    }

    public void checkUser(String useremail, String userpassword) {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");
        Query checkUserDatabase = reference.orderByChild("email").equalTo(useremail);

            checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    if(snapshot.exists()) {
                        memail.setError(null);
                        String passwordFromDB = snapshot.child(useremail).child("password").getValue(String.class);
                    if(passwordFromDB != null && passwordFromDB.equals(userpassword)){
                        // Successful login
                        Toast.makeText(getApplicationContext(), "Login successful", Toast.LENGTH_SHORT).show();}
                    else {
                        //incorrect password
                        mpassword.setError("Invalid Credentials");
                        mpassword.requestFocus();
                    }
                    }
                    else{
                        // user not found
                        memail.setError("User doesn't exist");
                        memail.requestFocus();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // handle database error
                    Toast.makeText(getApplicationContext(), "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();

                }
            });
        }


    private boolean validateinfo( String email, String password)
    {

         if(email.length() ==0)
        {
            memail.requestFocus();
            memail.setError("Field can't be empty");
            return false;
        }
        else if(!email.matches(  "[a-zA-Z0-9._-]+@+[a-z]+\\.+[a-z]+"))
        {
            memail.requestFocus();
            memail.setError("Enter valid email");
            return false;
        }

        else if(password.length() <=8)
        {
            mpassword.requestFocus();
            mpassword.setError("password must be 8 characters");
            return false;
        }
        else
        {
            return true;
        }

    }
}
